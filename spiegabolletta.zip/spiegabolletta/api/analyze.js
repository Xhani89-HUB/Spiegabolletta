// api/analyze.js — Vercel Serverless Function
// Questo file gestisce la chiave API Anthropic lato server, in modo sicuro.
// La chiave NON è mai esposta al browser.

export const config = { api: { bodyParser: { sizeLimit: '10mb' } } };

export default async function handler(req, res) {
  // CORS
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Metodo non consentito' });

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) return res.status(500).json({ error: 'Configurazione server mancante' });

  try {
    const { fileData, fileType, fileName } = req.body;
    if (!fileData || !fileType) return res.status(400).json({ error: 'Dati file mancanti' });

    const isImage = fileType.startsWith('image/');
    const supportedImageTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    const supportedPdfType = 'application/pdf';

    if (!isImage && fileType !== supportedPdfType) {
      return res.status(400).json({ error: 'Tipo file non supportato. Usa PDF, JPG o PNG.' });
    }
    if (isImage && !supportedImageTypes.includes(fileType)) {
      return res.status(400).json({ error: 'Formato immagine non supportato.' });
    }

    const systemPrompt = `Sei SpiegaBolletta, un assistente AI esperto in bollette elettriche italiane. 
Il tuo compito è analizzare bollette e spiegarle in linguaggio semplice e comprensibile per chiunque.
Sei preciso, empatico e mai tecnico al punto da confondere l'utente.
Rispondi SEMPRE e SOLO con un oggetto JSON valido, senza markdown, senza backtick, senza testo aggiuntivo.`;

    const userPrompt = `Analizza questa bolletta elettrica italiana (file: ${fileName || 'bolletta'}).

Rispondi con SOLO questo JSON (nessun testo prima o dopo):
{
  "fornitore": "Nome del fornitore se visibile, altrimenti null",
  "periodo": "Periodo di fatturazione (es. Gennaio 2025) se visibile, altrimenti null",
  "totale": "Importo totale (es. € 142,80) se visibile, altrimenti null",
  "spiegazione": "Spiegazione generale della bolletta in 4-6 frasi chiare. Spiega il totale, se è nella norma, cosa lo compone. Usa un tono amichevole.",
  "voci": [
    {
      "nome": "Nome della voce come appare in bolletta",
      "importo": "Importo (es. € 58,20) o null se non visibile",
      "categoria": "energia | oneri | trasporto | tasse | altro",
      "spiegazione": "Cosa significa questa voce in 1-2 frasi semplici"
    }
  ],
  "anomalie": [
    {
      "tipo": "aumento | consumo_alto | voce_insolita | altro",
      "descrizione": "Descrizione chiara dell'anomalia in 1-2 frasi",
      "gravita": "bassa | media | alta"
    }
  ],
  "suggerimenti": [
    "Suggerimento pratico 1",
    "Suggerimento pratico 2",
    "Suggerimento pratico 3"
  ],
  "punteggio_chiarezza": 75,
  "errore": null
}

Se il file non è una bolletta o non è leggibile, imposta errore: "descrizione del problema" e lascia gli altri campi null.
Se non ci sono anomalie, imposta anomalie: [].`;

    const content = isImage
      ? [
          { type: 'image', source: { type: 'base64', media_type: fileType, data: fileData } },
          { type: 'text', text: userPrompt }
        ]
      : [
          { type: 'document', source: { type: 'base64', media_type: 'application/pdf', data: fileData } },
          { type: 'text', text: userPrompt }
        ];

    const anthropicRes = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1500,
        system: systemPrompt,
        messages: [{ role: 'user', content }]
      })
    });

    if (!anthropicRes.ok) {
      const err = await anthropicRes.json();
      console.error('Anthropic error:', err);
      return res.status(502).json({ error: 'Errore nel servizio AI. Riprova tra poco.' });
    }

    const anthropicData = await anthropicRes.json();
    const rawText = anthropicData.content.map(b => b.text || '').join('').trim();
    const cleaned = rawText.replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/\s*```$/i, '').trim();

    let parsed;
    try {
      parsed = JSON.parse(cleaned);
    } catch {
      return res.status(200).json({ errore: 'Il file non è stato riconosciuto come bolletta leggibile. Assicurati che sia un PDF o immagine nitida.' });
    }

    return res.status(200).json(parsed);
  } catch (err) {
    console.error('Server error:', err);
    return res.status(500).json({ error: 'Errore interno del server. Riprova.' });
  }
}
