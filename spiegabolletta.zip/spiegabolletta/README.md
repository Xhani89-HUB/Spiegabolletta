# SpiegaBolletta — Guida al Deploy su Vercel

## Struttura del progetto

```
spiegabolletta/
├── api/
│   └── analyze.js      ← Backend serverless (chiave API sicura)
├── public/
│   └── index.html      ← Frontend completo
├── vercel.json         ← Configurazione Vercel
├── package.json        ← Dipendenze
└── README.md           ← Questa guida
```

---

## STEP 1 — Crea un account Vercel (gratis)

1. Vai su https://vercel.com
2. Clicca "Sign Up" → accedi con GitHub (consigliato)

---

## STEP 2 — Installa Vercel CLI

```bash
npm install -g vercel
```

---

## STEP 3 — Deploy

Nella cartella del progetto:

```bash
cd spiegabolletta
vercel
```

Segui le istruzioni:
- Set up and deploy? → **Y**
- Which scope? → scegli il tuo account
- Link to existing project? → **N**
- Project name → `spiegabolletta`
- Directory → `.` (lascia vuoto, premi Invio)

---

## STEP 4 — Aggiungi la chiave API Anthropic (FONDAMENTALE)

1. Vai su https://console.anthropic.com → API Keys → crea una nuova chiave
2. Nel dashboard Vercel del tuo progetto:
   - **Settings** → **Environment Variables**
   - Aggiungi: `ANTHROPIC_API_KEY` = `sk-ant-...` (la tua chiave)
   - Seleziona gli ambienti: Production + Preview + Development

3. Fai un nuovo deploy per applicare la variabile:
```bash
vercel --prod
```

---

## STEP 5 — Dominio personalizzato (opzionale)

1. Compra un dominio (es. su Namecheap, GoDaddy, o direttamente su Vercel)
2. In Vercel: **Settings** → **Domains** → aggiungi il tuo dominio
3. Segui le istruzioni DNS

---

## Test locale

```bash
vercel dev
```

Poi apri http://localhost:3000

Per il test locale, crea un file `.env.local`:
```
ANTHROPIC_API_KEY=sk-ant-tua-chiave-qui
```

---

## Note sulla sicurezza

- La chiave API Anthropic è **MAI esposta** al browser
- Il file `api/analyze.js` gira solo sul server Vercel
- I file caricati non vengono salvati (elaborazione in memoria)
- Per aggiungere rate limiting in futuro, usa Vercel Edge Middleware

---

## Prossimi sviluppi (Piano Plus/Pro)

Per i piani a pagamento dovrai aggiungere:
1. **Auth** → Clerk.dev o Auth.js (gratuiti per piccoli volumi)
2. **Pagamenti** → Stripe (checkout, abbonamenti, webhook)
3. **Database** → Planetscale o Supabase (storico analisi)
4. **Email** → Resend.com (conferma, alert)

Quando sei pronto, chiedimi di implementare uno di questi moduli.
